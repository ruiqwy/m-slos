
nruns_i<-1 # set the seed

require(fda)
require(MASS)

########################################################  function  dp  
Dpfunc <- function(u,lambda,a)  
{
  if(u<=lambda) Dpval <- lambda
  else if(u<a*lambda) Dpval <- -(u-a*lambda)/(a-1)
  else Dpval <- 0
  Dpval
}


########################################################  function  2norm
slos.vec.norm <- function(v) 
{
  sqrt(sum(v^2))
}


########################################################function  mse

slos.mse <- function(y,fitted.values)   
{
  mean((y-fitted.values)^2)
}


########################################################function  predict


predict.slos <- function(slosobj,newX,use.index=NULL,domain=NULL)
{
  xfd <- slos.preprocess.x(newX,domain)
  K <- length(xfd)
  y <- 0
  for(k in 1:K)
  {
    x <- xfd[[k]]
    b <- slosobj$beta[[k]]
    G <- inprod(x$basis,b$basis)
    if(!is.null(use.index))
      y <- y + t(x$coef[,use.index]) %*% G %*% b$coef
    else
      y <- y + t(x$coef) %*% G %*% b$coef
  }
  y <- y + slosobj$intercept
  y
  
}

########################################################function prepare data in the following way 
# K     :   the number of predictors
# xfd   :   list of K matrices / fd objects
slos.preprocess.x <- function(X,D)
{
  if(is.matrix(X) || is.fd(X))
  {
    Xtmp <- list()
    Xtmp[[1]] <- X
    X <- Xtmp
    K <- 1
  }
  else K <- length(X)
  
  xfd <- list()
  for(k in 1:K)
  {
    x <- X[[k]]
    if(!is.fd(x))
    {
      if(is.matrix(D)||is.vector(D))
      {
        x <- Data2fd(argvals=D,y=x)
      }
      else
      {
        x <- Data2fd(argvals=D[[k]],y=x)
      }
    }
    
    if(!is.fd(x))
      stop("X must be a matrix, fd object or a list of matrices/fd objects")
    xfd[[k]] <- x
  }
  xfd
}

########################################################function W[,,j]:W_j

slos.compute.weights <- function(basis) 
{
  L <- basis$nbasis 
  rng <- getbasisrange(basis)  
  breaks <- c(rng[1],basis$params,rng[2])  
  M <- length(breaks) - 1
  norder <- L-M+1  #  L = M + 1 + norder
  W <- array(0,dim=c(norder,norder,M))
  for (j in 1:M)
  {
    temp <- inprod(basis,basis,rng=c(breaks[j],breaks[j+1]))
    W[,,j] <- temp[j:j+norder-1,j:j+norder-1]
  }
  W
}



inner.prod <- function(f,basis,j){
  rng <- getbasisrange(basis)
  knots <- c(rng[1],basis$params,rng[2])
  nbasis <- basis$nbasis
  norder <- basis$nbasis - length(knots) + 2
  
  a <- rng[1]
  if(j-norder > 0) a <- knots[j-norder+1]
  
  b <- rng[2]
  if (j <= nbasis-norder) b <- knots[j+1]
  
  bfun <- function(t)
  {
    mat <- eval.basis(t,basis)
    z <- t(mat[,j])
  }
  
  y <- integrate(function(t) {f(t)*bfun(t)},a,b)
  y$value
}

########################################################function 

slos.int.lqa <- function(U,y,muhat,bHat,L,theta,intercept,wrap,Ws,Ms,Ls,L2NNer,ds,lambda,mylambda,a,VV,changeThres,max.iter,nbasis){
  Mmax <- max(Ms)
  Lmax <- max(Ls)
  K <- length(Ms)
  P <- c(0,cumsum(Ls))
  Mset<-length(y)
  n <- length(y[[1]])
  
  
  bZeroMat<-list()
  for (zero_mset in 1:Mset)  bZeroMat[[zero_mset]] <- matrix(FALSE,1,sum(Ls))
  
  betaNormj <- matrix(0,Mmax,K)
  
  betaNorm <- rep(Inf,K)
  
  it <- 1
  
  while (it <= max.iter){
    
    
    betaNormOld <- betaNorm
    
    for (k in 1:K){
      betaNorm[k] <-0
      for(norm_set in 1:Mset) betaNorm[k]<-betaNorm[k]+slos.vec.norm(bHat[[norm_set]][(P[k]+1):P[k+1]])
    }
    change <- max((betaNormOld-betaNorm)^2)
    if(change < changeThres) break
    
    
    lqaW <- list()
    for(w_mset in 1:Mset){
      in_lqaW<-NULL
      for (k in 1:K){  
        W <- Ws[[k]]
        lqaWk <- matrix(0,Ls[k],Ls[k])
        for(j in 1:Ms[k]){
          index <- c(j:(j+ds[k]))
          
          bkj <- bHat[[w_mset]][P[k]+c(j:(j+ds[k]))]
          betaNormj[j,k] <- sqrt(t(bkj) %*% W[,,j] %*% bkj)
          cjk <- Dpfunc(betaNormj[j,k]*L2NNer[k],lambda,a)
          if(cjk != 0){
            if(betaNormj[j,k] < changeThres) bZeroMat[[w_mset]][P[k]+index] <- TRUE
            else lqaWk[index,index] <- lqaWk[index,index] + cjk*(L2NNer[k]/betaNormj[j,k])*W[,,j]
          }
        }
        if(is.null(in_lqaW)) in_lqaW <- lqaWk
        else in_lqaW <- bdiag(in_lqaW,lqaWk)
      }
      lqaW[[w_mset]]<-in_lqaW
    }
    
    
    bZeroVec <- bZeroMat
    bNonZeroVec<-list()
    for(benon_mset in 1:Mset)  bNonZeroVec[[benon_mset]] <- !bZeroVec[[benon_mset]]
    
    
    if(intercept){
      for(inter_mset in 1:Mset){
        lqaW[[inter_mset]] <- bdiag(0,lqaW[[inter_mset]])
        bNonZeroVec[[inter_mset]] <- c(TRUE,bNonZeroVec[[inter_mset]])
      } 
    }
    
    for(q_mset in 1:Mset) lqaW[[q_mset]] <- Mset*lqaW[[q_mset]] / 2  #/q
    
    
    if(abs(mylambda)>1e-12){
      ######接下来是计算我们的penality 
      left<-list()
      for(left_mset in 1:Mset) left[[left_mset]] <-n*Mset*mylambda*L[left_mset,left_mset]*t(theta)
      
      right<-list()
      for(right_mset in 1:Mset){
        in_right<-matrix(0,nbasis,1)
        for(right_l in 1:Mset){
          if(right_l!=right_mset) in_right<-in_right+L[right_mset,right_l]*t(theta)%*%bHat[[right_mset]]
        }
        right[[right_mset]]<-in_right*n*Mset*mylambda
      }
      
      if (intercept){
        for(intercept_rl_set in 1:Mset){
          right[[intercept_rl_set]] <- rbind(0,right[[intercept_rl_set]])
          left[[intercept_rl_set]] <- bdiag(0,left[[intercept_rl_set]])
          bHat[[intercept_rl_set]]<-rbind(muhat[[intercept_rl_set]],bHat[[intercept_rl_set]])
        }
      }
      
      
      for(slove_mset in 1:Mset){
        
        UtU <- t(U[[slove_mset]][,bNonZeroVec[[slove_mset]]]) %*% U[[slove_mset]][,bNonZeroVec[[slove_mset]]]
        Ut <- t(U[[slove_mset]][,bNonZeroVec[[slove_mset]]])
        Vp <- VV[[slove_mset]][bNonZeroVec[[slove_mset]],bNonZeroVec[[slove_mset]]]*Mset  #已经乘以q
        
        solve_theta <- solve(UtU+Vp+n*lqaW[[slove_mset]][bNonZeroVec[[slove_mset]],bNonZeroVec[[slove_mset]]]+left[[slove_mset]][bNonZeroVec[[slove_mset]],bNonZeroVec[[slove_mset]]],Ut %*% y[[slove_mset]]-right[[slove_mset]][bNonZeroVec[[slove_mset]]])
        bHat[[slove_mset]] <- matrix(0,length(bNonZeroVec[[slove_mset]]),1)
        bHat[[slove_mset]][bNonZeroVec[[slove_mset]],1] <- matrix(solve_theta,length(solve_theta),1)
        
        if (intercept){
          muhat[[slove_mset]]<-bHat[[slove_mset]][1]
          bHat[[slove_mset]]<-bHat[[slove_mset]][-1]
        }
      }
    }else{
      
      for(slove_mset in 1:Mset){
        
        UtU <- t(U[[slove_mset]][,bNonZeroVec[[slove_mset]]]) %*% U[[slove_mset]][,bNonZeroVec[[slove_mset]]]
        Ut <- t(U[[slove_mset]][,bNonZeroVec[[slove_mset]]])
        Vp <- VV[[slove_mset]][bNonZeroVec[[slove_mset]],bNonZeroVec[[slove_mset]]]*Mset  #已经乘以q
        
        solve_theta <- solve(UtU+Vp+n*lqaW[[slove_mset]][bNonZeroVec[[slove_mset]],bNonZeroVec[[slove_mset]]],Ut %*% y[[slove_mset]])
        bHat[[slove_mset]] <- matrix(0,length(bNonZeroVec[[slove_mset]]),1)
        bHat[[slove_mset]][bNonZeroVec[[slove_mset]],1] <- matrix(solve_theta,length(solve_theta),1)
        
        if (intercept){
          muhat[[slove_mset]]<-bHat[[slove_mset]][1]
          bHat[[slove_mset]]<-bHat[[slove_mset]][-1]
        }
        
      }
    }
    
    
    it <- it + 1
    
    #cat('it=',it,'  ')
    
  }
  
  bHat
}


########################################################function 
slos.int.alg <- function(xfd,y,fit_now,L,theta,lambda,gamma,mylambda,intercept,wrap,beta.basis,cutoff,
                         max.iter,tol,a,Jmat,Vs=NULL,Ws=NULL,use.index=NULL,nbasis=nbasis)
{
  # get some constants
  Mset<-length(xfd)
  K <- length(xfd[[1]])
  Ls <- rep(0,K)
  Ms <- rep(0,K)
  ds <- rep(0,K)
  L2NNer <- rep(0,K)
  
  for (k in 1:K) Ls[k] <- beta.basis[[1]][[k]]$nbasis   #记录第k个变量的基函数个数
  for (k in 1:K) Ms[k] <- length(beta.basis[[1]][[k]]$params) + 1  #记录第k个变量的内部结点数目+1
  for (k in 1:K) ds[k] <- Ls[k] - Ms[k]  # order 3  
  for (k in 1:K) L2NNer[k] <- sqrt(Ms[k]/diff(getbasisrange(xfd[[1]][[k]]$basis)))  # sqrt(M/T)
  P <- c(0,cumsum(Ls))
  
  # compute weight and roughness penalty matrices if they are NULL
  #Vs=NULL
  if(is.null(Vs)) {
    Vs <- list()
    for(k in 1:K){
      Vs[[k]] <- eval.penalty(beta.basis[[1]][[k]],int2Lfd(2))
    }
  }
  #Ws=NULL
  if(is.null(Ws[[1]])){
    Ws <- list()
    for(k in 1:K){
      Ws[[k]] <- slos.compute.weights(beta.basis[[1]][[k]])  #这里的k是指的变量个数
    }
  }
  
  #if(!is.null(use.index)) y <- y[use.index]
  
  # compute design matrix
  U <- list()
  VV <- list()
  
  n <- length(y[[1]])   
  
  
  for(ido in 1:Mset) {
    in_U<-NULL
    in_VV<-NULL
    for (k in 1:K){
      xcoef <- xfd[[ido]][[k]]$coefs # M by n
      in_U <- cbind(in_U,t(xcoef)%*%Jmat[[k]])  
      if(is.null(in_VV))  in_VV <- n*gamma*Vs[[k]]
      else in_VV <- bdiag(in_VV,n*gamma*Vs[[k]])
    }
    U[[ido]]<-in_U
    VV[[ido]]<-in_VV
  }
  
  if(intercept){
    for (ido in 1:Mset){
      U[[ido]] <- cbind(matrix(1,n,1),U[[ido]])
      VV[[ido]] <- bdiag(0,VV[[ido]])
    }
  }
  
  # compute the initial estimate
  bHat <- list()
  for (ido in 1:Mset){
    bHat[[ido]] <- fit_now[[ido]]$beta[[1]]$coefs
  }
  
  
  if(intercept){
    muhat<-list()
    for (ido in 1:Mset){
      muhat[[ido]] <- fit_now[[ido]]$intercept
    }
  }
  
  
  bTilde <- bHat # if sparse, perform SLoS, otherwise, bTilde is the solution to \beta
  #list
  
  if(lambda > 0){
    changeThres <- tol
    bTilde <- slos.int.lqa(U=U,y=y,muhat=muhat,bHat=bHat,L=L,theta=theta,intercept=T,wrap=F,Ws=Ws,Ms=Ms,Ls=Ls,L2NNer=L2NNer,ds=ds,
                           lambda=lambda,mylambda=mylambda,a=3.7,VV=VV,changeThres=changeThres,max.iter=max.iter,nbasis=nbasis)
    bZero<-list()
    for (ido in 1:Mset){
      bZero[[ido]] <- ((abs(bTilde[[ido]])) < cutoff)
      bTilde[[ido]][bZero[[ido]]] <- 0
    }
    
    bNonZero<-list()
    if(intercept){
      for(ido in 1:Mset){
        bTilde[[ido]] <- c(muhat[[ido]],bTilde[[ido]])
        bNonZero[[ido]] <- c(TRUE,!bZero[[ido]])
      }
    }
    if(!intercept) for(ido in 1:Mset) bNonZero[[ido]] <- !bZero[[ido]]
    
  }
  
  
  result<-list()
  
  for (ido in 1:Mset) {
    U1 <- U[[ido]][,bNonZero[[ido]]]
    V1 <- VV[[ido]][bNonZero[[ido]],bNonZero[[ido]]]
    
    
    result[[ido]] <- list(beta=fit_now[[ido]]$beta,intercept=0    )
    
    if(intercept){
      result[[ido]]$beta[[1]]$coefs<-bTilde[[ido]][-1]
      result[[ido]]$intercept<-muhat[[ido]]
    }
    if(!intercept){
      result[[ido]]$beta[[1]]$coefs<-bTilde[[ido]]
    }
    
    class(result[[ido]]) <- 'slos'
    result[[ido]]$fitted.values<-predict(result[[ido]],X[[ido]])
    result[[ido]]$lambda<-lambda
    result[[ido]]$mylambda<-mylambda
    result[[ido]]$gamma<-gamma
    result[[ido]]$projMat <- U1 %*% solve(t(U1)%*%U1+V1,t(U1))
    
  }
  
  result   
  
}



####################################################main function

int.slos <- function(X,y,fit_now,L,theta,K=1,D=NULL,lambda=0,gamma=0,mylambda=0,intercept=T,wrap=FALSE,beta.basis=NULL,cutoff=1e-4,
                     max.iter=1000,tol=1e-12,a=3.7,domain=NULL,tuning='BIC',nbasis=nbasis)
{
  # D     : the design points
  # X     : predictor(s), could be a matrix (fd object) or list of matrix (fd objects)
  #         if matrix, then it is organized in the way that each column is an independent observation
  # y     : a column vector, the response
  
  
  ################### prepare data in the following way #####################
  # K     :   the number of predictors
  # xfd   :   list of K matrices / fd objects
  # design:   the design points for each objects
  Mset<-length(X)
  xfd<-list()
  for (ido in 1:Mset) xfd[[ido]] <- slos.preprocess.x(X[[ido]],D)  #xfd[[mset]][[第i个变量]]
  
  ######################### prepare basis for coefficient functions #############
  #beta.basis=NULL
  if(is.null(beta.basis)){
    beta.basis <- list()
    for(ido in 1:Mset){
      for(k in 1:K){
        beta.basis[[ido]]<-list()
        x <- xfd[[ido]][[k]]
        rng <- getbasisrange(x$basis)
        beta.basis[[ido]][[k]] <- create.bspline.basis(rangeval=rng,norder=norder,nbasis=nbasis) 
      }
    }
  }
  ######################### inprod between x and beta #############
  Jmat <- list()
  for(k in 1:K)   Jmat[[k]] <- inprod(xfd[[1]][[k]]$basis,beta.basis[[1]][[k]])  #我们假设beta.basis是一样的,这里的k是变量
  
  
  ######################### tuned #################################
  
  if(length(gamma)>1 || length(lambda)>1 || length(mylambda)>1){
    tuned <- slos.int.tune(xfd=xfd,y=y,fit_now=fit_now,L=L,theta=theta,lambda=lambda,gamma=gamma,mylambda=mylambda,intercept=T,wrap=F,beta.basis=beta.basis,cutoff=cutoff,
                           max.iter=max.iter,tol=tol,a=3.7,Jmat=Jmat,tuning=tuning,Vs=NULL,Ws=NULL)
    result<-slos.int.alg(xfd=xfd,y=y,fit_now=fit_now,L=L,theta=theta,lambda=tuned$lambda,gamma=tuned$gamma,mylambda=tuned$mylambda,intercept=T,wrap=F,beta.basis=beta.basis,cutoff=cutoff,
                         max.iter=max.iter,tol=tol,a=3.7,Jmat=Jmat)
    for(tune in 1:Mset) {
      result[[tune]]$lambda <- tuned$lambda
      result[[tune]]$gamma <- tuned$gamma
      result[[tune]]$mylambda <- tuned$mylambda
      result[[tune]]$score <- tuned$score
    }
    
    result
  }else{
    result<-slos.int.alg(xfd=xfd,y=y,fit_now=fit_now,L=L,theta=theta,lambda=lambda,gamma=gamma,mylambda=mylambda,intercept=T,wrap=F,beta.basis=beta.basis,cutoff=cutoff,
                         max.iter=max.iter,tol=tol,a=3.7,Jmat=Jmat,nbasis=nbasis)
    result
  }
  
}



slos <- function(X,y,K=1,D=NULL,lambda=0,gamma=0,intercept=T,wrap=FALSE,beta.basis=NULL,cutoff=1e-4,
                 max.iter=1000,tol=1e-12,a=3.7,domain=NULL,tuning=NULL)
{
  # D     : the design points
  # X     : predictor(s), could be a matrix (fd object) or list of matrix (fd objects)
  #         if matrix, then it is organized in the way that each column is an independent observation
  # y     : a column vector, the response
  
  ################ sanity check #####################
  
  if(!require('fda'))
    stop("The slos function depends on the fda package which is missing")
  if(is.null(D))
  {
    if(is.matrix(X))
      stop("The design should be provided when X is matrix")
  }
  
  if(is.matrix(X) || is.fd(X)) # there is only one predictor, convert it into a fd object
  {
    X <- list(x=X)
  }
  
  if(!is.list(X))
    stop("X must be a matrix, fd object or a list of matrices/fd objects")
  
  ################### prepare data in the following way #####################
  # K     :   the number of predictors
  # xfd   :   list of K matrices / fd objects
  # design:   the design points for each objects
  
  xfd <- slos.preprocess.x(X,D)
  
  ######################### prepare basis for coefficient functions #############
  
  if(is.null(beta.basis))
  {
    beta.basis <- list()
    for(k in 1:K)
    {
      x <- xfd[[k]]
      rng <- getbasisrange(x$basis)
      beta.basis[[k]] <- create.bspline.basis(rangeval=rng,nbasis=73)
    }
  }
  
  Jmat <- list()
  for(k in 1:K)   Jmat[[k]] <- inprod(xfd[[k]]$basis,beta.basis[[k]])
  
  if(length(gamma)>1 || length(lambda)>1)
  {
    tuned <- slos.tune(xfd,y,lambda,gamma,intercept,wrap,beta.basis,cutoff,
                       max.iter,tol,a,Jmat,tuning)
    result <- slos.alg(xfd,y,tuned$lambda,tuned$gamma,intercept,wrap,beta.basis,cutoff,
                       max.iter,tol,a,Jmat)
    result$lambda <- tuned$lambda
    result$gamma <- tuned$gamma
    result$score <- tuned$score
    result
  }
  else
  {
    slos.alg(xfd,y,lambda,gamma,intercept,wrap,beta.basis,cutoff,
             max.iter,tol,a,Jmat)
  }
  
}


########################################################function 

slos.tune <- function(xfd,y,lambda,gamma,intercept,wrap,beta.basis,cutoff,
                      max.iter,tol,a,Jmat,tuning,Vs=NULL,Ws=NULL)
{
  K <- length(xfd)
  # compute weight and roughness penalty matrices if they are NULL
  if(is.null(Vs))
  {
    Vs <- list()
    for(k in 1:K)
    {
      Vs[[k]] <- eval.penalty(beta.basis[[k]],int2Lfd(2))
    }
  }
  
  if(is.null(Ws))
  {
    Ws <- list()
    for(k in 1:K)
    {
      Ws[[k]] <- slos.compute.weights(beta.basis[[k]])
    }
  }
  
  dm <- dim(xfd[[1]]$coef)
  n <- dm[2]
  
  if(tuning == 'VALIDATION')
  {
    val.xfd <- slos.preprocess.x(attr(tuning,'X'))
    val.y <- attr(tuning,'y')
  }
  
  err.score <- matrix(0,length(lambda),length(gamma))
  for(i in 1:length(lambda))
  {
    for(j in 1:length(gamma))
    {
      if(tuning != 'CV' && tuning != 'VALIDATION')
      {
        fit <- slos.alg(xfd,y,lambda[i],gamma[j],intercept,wrap,beta.basis,cutoff,
                        max.iter,tol,a,Jmat,Vs,Ws,use.index=NULL)
        resid <- y-fit$fitted.values
        rss <- sum(resid^2)
        df <- sum(diag(fit$projMat))
        
        if(tuning == 'RIC')
        {
          sig2 <- rss/(n-df)
          err <- (n-df)*log(sig2)+df*(log(n)-1)+4/(n-df-2)
        }
        else if(tuning == 'AIC')
        {
          err = n*log(rss/n)+2*df
        }
        else if(tuning == 'BIC')
        {
          err = n*log(rss/n) + log(n)*df
        }
        else stop("Unrecognized tuning criterion")
      }
      else if(tuning == 'VALIDATION')
      {
        fit <- slos.alg(xfd,y,lambda[i],gamma[j],intercept,wrap,beta.basis,cutoff,
                        max.iter,tol,a,Jmat,Vs,Ws,use.index=NULL)
        yhat <- predict(fit,val.xfd)
        resid <- val.y - yhat
        err <- sum(resid^2)
      }
      else if(tuning == 'CV')
      {
        cv.type <- attr(tuning,'type')
        if (is.null(cv.type)) cv.type <- "k-fold"
        if (cv.type == 'leave-one-out') Kfold <- n
        else Kfold <- attr(tuning,'K')
        if (is.null(K)) Kfold <- 10
        idx <- sample(1:n,n) # shuffle data
        
        s <- ceiling(n/Kfold)
        
        err.cv <- matrix(0,1,Kfold)
        for(k in 1:Kfold)
        {
          test.index <- idx[(s*(k-1)+1):min(s*k,n)]
          train.index <- idx[-(s*(k-1)+1):min(s*k,n)]
          fit <- slos.alg(xfd,y,lambda[i],gamma[j],intercept,wrap,beta.basis,cutoff,
                          max.iter,tol,a,Jmat,Vs,Ws,use.index=train.index)
          yhat <- predict(fit,xfd,test.index)
          resid <- y[test.index] - yhat
          err.cv[k] <- sum(resid^2)
        }
        
        err <- sum(err.cv)
      }
      
      err.score[i,j] <- err
    }
  }
  
  h <- which(err.score==min(err.score),arr.ind=T)
  list(score=err.score,lambda=lambda[h[1,1]],gamma=gamma[h[1,2]],min.score=min(err.score))
}

########################################################function 

slos.mse <- function(y,fitted.values)
{
  mean((y-fitted.values)^2)
}

########################################################function 

slos.preprocess.x <- function(X,D)
{
  if(is.matrix(X) || is.fd(X))
  {
    Xtmp <- list()
    Xtmp[[1]] <- X
    X <- Xtmp
    K <- 1
  }
  else K <- length(X)
  
  xfd <- list()
  for(k in 1:K)
  {
    x <- X[[k]]
    if(!is.fd(x))
    {
      if(is.matrix(D)||is.vector(D))
      {
        x <- Data2fd(argvals=D,y=x)
      }
      else
      {
        x <- Data2fd(argvals=D[[k]],y=x)
      }
    }
    
    if(!is.fd(x))
      stop("X must be a matrix, fd object or a list of matrices/fd objects")
    xfd[[k]] <- x
  }
  
  xfd
  
}

########################################################function 


slos.compute.weights <- function(basis) # 
{
  L <- basis$nbasis  
  rng <- getbasisrange(basis)  
  breaks <- c(rng[1],basis$params,rng[2])  
  M <- length(breaks) - 1
  norder <- L-M+1  #  L = M + 1 + norder
  W <- array(0,dim=c(norder,norder,M))
  for (j in 1:M)
  {
    temp <- inprod(basis,basis,rng=c(breaks[j],breaks[j+1]))
    W[,,j] <- temp[j:j+norder-1,j:j+norder-1]
  }
  W
}

########################################################function 


slos.alg <- function(xfd,y,lambda,gamma,intercept,wrap,beta.basis,cutoff,
                     max.iter,tol,a,Jmat,Vs=NULL,Ws=NULL,use.index=NULL)
{
  # get some constants
  K <- length(xfd)
  Ls <- rep(0,K)
  Ms <- rep(0,K)
  ds <- rep(0,K)
  L2NNer <- rep(0,K)
  
  for (k in 1:K) Ls[k] <- beta.basis[[k]]$nbasis    
  for (k in 1:K) Ms[k] <- length(beta.basis[[k]]$params) + 1   
  for (k in 1:K) ds[k] <- Ls[k] - Ms[k]   
  for (k in 1:K) L2NNer[k] <- sqrt(Ms[k]/diff(getbasisrange(xfd[[k]]$basis)))
  P <- c(0,cumsum(Ls))
  
  # compute weight and roughness penalty matrices if they are NULL
  if(is.null(Vs))
  {
    Vs <- list()
    for(k in 1:K)
    {
      Vs[[k]] <- eval.penalty(beta.basis[[k]],int2Lfd(2))
    }
  }
  
  if(is.null(Ws))
  {
    Ws <- list()
    for(k in 1:K)
    {
      Ws[[k]] <- slos.compute.weights(beta.basis[[k]])
    }
  }
  
  # compute design matrix
  U <- NULL
  VV <- NULL
  
  if(!is.null(use.index)) y <- y[use.index]
  
  n <- length(y)
  
  for (k in 1:K)
  {
    xcoef <- xfd[[k]]$coefs # M by n
    if(!is.null(use.index))
    {
      U <- cbind(U,t(xcoef[,use.index])%*%Jmat[[k]])
      VV <- bdiag(VV,n*gamma*Vs[[k]])
    }
    else
    {
      U <- cbind(U,t(xcoef)%*%Jmat[[k]])
      if(is.null(VV))  VV <- n*gamma*Vs[[k]]
      else VV <- bdiag(VV,n*gamma*Vs[[k]])
    }
  }
  
  if (wrap)
  {
    oldU <- U
    oldV <- VV
    dimU <- dim(U)
    dimV <- dim(VV)
    U <- cbind(U[,1]+U[,dimU[2]],U[,2:(dimU[2]-1)])
    VV[,1] <- VV[,1] + VV[,dimV[2]]
    VV[1,] <- VV[1,] + VV[dimV[1],]
    VV <- VV[-dimV[1],-dimV[2]]
  }
  
  if(intercept)
  {
    U <- cbind(matrix(1,n,1),U)
    VV <- bdiag(0,VV)
  }
  
  # compute the initial estimate
  bHat <- solve(t(U)%*%U+VV,t(U)%*%y)
  
  if(intercept)
  {
    muhat <- bHat[1]
    bHat <- bHat[-1]
  }
  
  # now, potential intercept has been removed from bHat
  # if periodic, patch the bHat in the end
  if(wrap)
  {
    bHat <- c(bHat,bHat[1])
  }
  
  bTilde <- bHat
  
  # if sparse, perform SLoS, otherwise, bTilde is the solution to \beta
  if(lambda > 0)
  {
    changeThres <- tol
    bTilde <- slos.lqa(U,y,bHat,intercept,wrap,Ws,Ms,Ls,L2NNer,ds,
                       lambda,a,VV,changeThres,max.iter)
    bZero <- (abs(bTilde) < cutoff)
    bTilde[bZero] <- 0
    
    if(intercept)
    {
      bTilde <- rbind(muhat,bTilde)
      bNonZero <- c(TRUE,!bZero)
    }
    else bNonZero <- !bZero
    
    if(wrap)
    {
      bNonZeroPrime <- bNonZero[-length(bNonZero)]
      U1 <- U[,bNonZeroPrime]
      V1 <- VV[bNonZeroPrime,bNonZeroPrime]
      bb <- solve(t(U1)%*%U1+V1,t(U1)%*%y)
      bTilde <- matrix(0,dim(U)[2],1)
      bTilde[bNonZeroPrime,1] <- matrix(bb,length(bb),1)
      if(intercept)
      {
        bTilde <- c(bTilde,bTilde[2])
      }
      else
      {
        bTilde <- c(bTilde,bbTilde[1])
      }
    }
    else
    {
      U1 <- U[,bNonZero]
      V1 <- VV[bNonZero,bNonZero]
      bb <- solve(t(U1)%*%U1+V1,t(U1)%*%y)
      if(intercept)
      {
        bTilde <- matrix(0,1+sum(Ls),1)
        bTilde[bNonZero,1] <- matrix(bb,length(bb),1)
      }
      else
      {
        bTilde <- matrix(0,sum(Ls),1)
        bTilde[bNonZero,1] <- matrix(bb,length(bb),1)
      }
    }
  }
  
  bNonZero <- as.vector((bTilde != 0))
  if(wrap)
  {
    U1 <- U[,bNonZero[-length(bNonZero)]]
    V1 <- VV[bNonZero[-length(bNonZero)],bNonZero[-length(bNonZero)]]
  }
  else
  {
    U1 <- U[,bNonZero]
    V1 <- VV[bNonZero,bNonZero]
  }
  
  projMat <- U1 %*% solve(t(U1)%*%U1+V1,t(U1))
  result <- list(beta=NULL,projMat=projMat,intercept=0,fitted.values=projMat%*%y)
  if(intercept)
  {
    result$intercept <- bTilde[1]
    bTilde <- bTilde[-1]
  }
  betaobj <- list()
  for(k in 1:K)
  {
    bfd <- fd(coef=bTilde[(P[k]+1):(P[k+1])],basisobj=beta.basis[[k]])
    betaobj[[k]] <- bfd
  }
  result$beta <- betaobj
  class(result) <- 'slos'
  result
  
}

########################################################function 


predict.slos <- function(slosobj,newX,use.index=NULL,domain=NULL)
{
  xfd <- slos.preprocess.x(newX,domain)
  K <- length(xfd)
  y <- 0
  for(k in 1:K)
  {
    x <- xfd[[k]]
    b <- slosobj$beta[[k]]
    G <- inprod(x$basis,b$basis)
    if(!is.null(use.index))
      y <- y + t(x$coef[,use.index]) %*% G %*% b$coef
    else
      y <- y + t(x$coef) %*% G %*% b$coef
  }
  y <- y + slosobj$intercept
  y
  
}

########################################################function 


slos.vec.norm <- function(v)
{
  sqrt(sum(v^2))
}

########################################################function 


slos.lqa <- function(U,y,bHat,intercept,wrap,Ws,Ms,Ls,L2NNer,ds,lambda,a,V,changeThres,max.iter)
{
  Mmax <- max(Ms)
  Lmax <- max(Ls)
  K <- length(Ms)
  P <- c(0,cumsum(Ls))
  
  n <- length(y)
  
  betaNormj <- matrix(0,Mmax,K)
  bZeroMat <- matrix(FALSE,1,sum(Ls))
  
  betaNorm <- rep(Inf,K)
  it <- 1
  
  while (it <= max.iter)
  {
    betaNormOld <- betaNorm
    for (k in 1:K)
    {
      betaNorm[k] <- slos.vec.norm(bHat[(P[k]+1):P[k+1]])
    }
    change <- max((betaNormOld-betaNorm)^2)
    if(change < changeThres) break
    
    lqaW <- NULL
    for (k in 1:K)
    {
      W <- Ws[[k]]
      lqaWk <- matrix(0,Ls[k],Ls[k])
      for(j in 1:Ms[k])
      {
        index <- c(j:(j+ds[k]))
        bkj <- bHat[P[k]+c(j:(j+ds[k]))]
        betaNormj[j,k] <- sqrt(t(bkj) %*% W[,,j] %*% bkj)
        cjk <- Dpfunc(betaNormj[j,k]*L2NNer[k],lambda,a)
        if(cjk != 0)
        {
          if(betaNormj[j,k] < changeThres) bZeroMat[P[k]+index] <- TRUE
          else lqaWk[index,index] <- lqaWk[index,index] + cjk*(L2NNer[k]/betaNormj[j,k])*W[,,j]
        }
      }
      
      if(is.null(lqaW)) lqaW <- lqaWk
      else lqaW <- bdiag(lqaW,lqaWk)
    }
    
    bZeroVec <- bZeroMat
    bNonZeroVec <- !bZeroVec
    
    if(wrap)
    {
      if(bNonZeroVec[length(bNonZeroVec)]==FALSE || 
         bNonZeroVec[1+intercept]==FALSE)
      {
        bNonZeroVec[1+intercept] <- FALSE
        bNonZeroVec[length(bNonZeroVec)] <- FALSE
      }
      
      dimW <- dim(lqaW)
      lqaW[,1] <- lqaW[,1] + lqaW[,dimW[2]]
      lqaW[1,] <- lqaW[1,] + lqaW[dimW[1],]
      lqaW <- lqaW[-dimW[1],-dimW[2]]
    }
    
    if(intercept)
    {
      lqaW <- bdiag(0,lqaW)
    }
    
    lqaW <- lqaW / 2
    
    
    if(intercept)  bNonZeroVec <- c(TRUE,bNonZeroVec)
    
    if(wrap)
    {
      bNonZeroVecPrime <- bNonZeroVec[-length(bNonZeroVec)]
      UtU <- t(U[,bNonZeroVecPrime]) %*% U[,bNonZeroVecPrime]
      Ut <- t(U[,bNonZeroVecPrime])
      Vp <- V[bNonZeroVecPrime,bNonZeroVecPrime]
      
      theta <- solve(UtU+Vp+n*lqaW[bNonZeroVecPrime,bNonZeroVecPrime],Ut %*% y)
      bHat <- matrix(0,length(bNonZeroVecPrime),1)
      bHat[bNonZeroVecPrime,1] <- matrix(theta,length(theta),1)
    }
    else
    {
      UtU <- t(U[,bNonZeroVec]) %*% U[,bNonZeroVec]
      Ut <- t(U[,bNonZeroVec])
      Vp <- V[bNonZeroVec,bNonZeroVec]
      
      theta <- solve(UtU+Vp+n*lqaW[bNonZeroVec,bNonZeroVec],Ut %*% y)
      bHat <- matrix(0,length(bNonZeroVec),1)
      bHat[bNonZeroVec,1] <- matrix(theta,length(theta),1)
    }
    
    
    
    if(intercept) bHat <- bHat[-1]
    if(wrap) bHat <- c(bHat,bHat[1])
    
    it <- it + 1
    
  }
  
  bHat
}

########################################################function 


Dpfunc <- function(u,lambda,a)
{
  if(u<=lambda) Dpval <- lambda
  else if(u<a*lambda) Dpval <- -(u-a*lambda)/(a-1)
  else Dpval <- 0
  Dpval
}

########################################################################
########################        example 1      #########################
########################################################################

nruns=1000
nSimu=nruns
n=300 
m=1000
k=1000
N<-n+m+k
intercept=1
rangeval=c(0,1)
Mset<-3



nbasis=50+4-2   
norder=4
basebeta<-create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
betaxprd<-inprod(basebeta,basebeta)  
theta<-inprod(basebeta,basebeta,rng=rangeval)

######################################################## get the beta coef
betacoe<-matrix(0,nrow = nbasis,ncol = Mset)


beta.func1 <- function(t){
  
  
  y<-3*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y1<-x
for(i in 1:length(x)){
  y1[i]<-beta.func1(x[i])
}
y1<-pmax(y1,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y1, basisobj)
yfd  <- result$fd
betacoe[,1]<-yfd$coefs
bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ")

###
beta.func2 <- function(t){
  
  
  y<-5*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y2<-x
for(i in 1:length(x)){
  y2[i]<-beta.func2(x[i])
}
y2<-pmax(y2,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y2, basisobj)
yfd  <- result$fd
betacoe[,2]<-yfd$coefs
###

beta.func3 <- function(t){
  
  
  y<-10*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y3<-x
for(i in 1:length(x)){
  y3[i]<-beta.func3(x[i])
}
y3<-pmax(y3,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y3, basisobj)
yfd  <- result$fd
betacoe[,3]<-yfd$coefs


bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

coe<-betacoe[,1]
coe[which(abs(coe)<=sqrt(sum((betacoe[,1])^2))*1e-4)]<-0
betacoe[,1]<-coe

coe<-betacoe[,2]
coe[which(abs(coe)<=sqrt(sum((betacoe[,2])^2))*1e-4)]<-0
betacoe[,2]<-coe

coe<-betacoe[,3]
coe[which(abs(coe)<=sqrt(sum((betacoe[,3])^2))*1e-4)]<-0
betacoe[,3]<-coe
betacoe[,1]<-betacoe[,3]
betacoe[,2]<-betacoe[,3]

plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ",ylim = c(-3.5,6.5))
lines(fd(betacoe[,2],bspl13),col="red")

lines(fd(betacoe[,3],bspl13),col="blue")

######################################################## error

set.seed(1)
sample1<-sample(1:1e5,nruns,replace = F)

error=list()
for(err_i in 1:nruns){
  set.seed(sample1[err_i])
  error[[err_i]]<-mvrnorm(n=N,mu=rep(0,Mset),Sigma = diag(Mset))  #error[[nruns]][,mset]
}
######################################################## x
set.seed(2)
sample2<-sample(1:1e5,nruns,replace = F)

N <- n + k + m
xmat<-list()
xcoef<-list()
for(m_i in 1:nruns){
  set.seed(sample2[m_i])
  
  xcoef[[m_i]]<-matrix(runif(N*nbasis,min = -5,max = 5),N,nbasis)
  xmat[[m_i]]<-xcoef[[m_i]]%*%betaxprd
}

######################################################## y
dat<-list()
for(mset in 1:Mset){
  train <- list()
  valid <- list()
  test <- list()
  
  for(gen_i in 1:nruns){
    cMat1<-xmat[[gen_i]]
    yTru<-intercept+cMat1%*%betacoe[,mset]
    y <- yTru + error[[gen_i]][,mset]*0.1
    
    train[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][1:n,]),basisobj=basebeta),y=y[1:n],intercept=intercept)
    if(k > 0) valid[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+1):(n+k),]),basisobj=basebeta),
                                     y=y[(n+1):(n+k)],intercept=intercept,yTru=yTru[(n+1):(n+k)])
    if(m > 0) test[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+k+1):N,]),basisobj=basebeta),
                                    y=y[(n+k+1):N],intercept=intercept,yTru=yTru[(n+k+1):N])
  }
  
  dat[[mset]] <- list(train=train,valid=valid,test=test)
  
}


####################################################################
A<-list()

for(iruns in 1:nruns){
  sample<-matrix(0,n,Mset)
  for(imset in 1:Mset){
    sample[,imset]<-dat[[imset]]$train[[iruns]]$y
  }
  
  mycorr <- cor ( sample ) 
  
  
  A[[iruns]]=mycorr
  
}


L<-list()
for(i in 1:nruns){
  DD=matrix(0,Mset,Mset)
  for(DD_i in 1:Mset){
    DD[DD_i,DD_i]<-sum(abs(A[[i]][DD_i,]))
  }
  L[[i]]=DD-A[[i]]
}


####################################################
###nruns_i


dat_now<-list()
for(mset in 1:Mset) {
  if (k!=0) {
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=dat[[mset]]$valid[[nruns_i]],test=dat[[mset]]$test[[nruns_i]])
  }
  if(k==0){
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=list(),test=dat[[mset]]$test[[nruns_i]])
    
  }
}
####################

XX<-list()
yy<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}
fit_now1<-list()

set.seed(1314)
sample_cv<-sample(1:1e5, nruns, replace = FALSE)
loc<-list()

for (i in 1:Mset){
  beta.basis111 <- list()
  beta.basis111[[1]] <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
  
  lambdaall1<-c(seq(0.0001,0.0009,by=0.0001)*0.1,0.0001,0.0002,0.0003,0.0004,seq(from=0.0005,to=0.001,by=0.00005),seq(from=0.002,to=0.014,by=0.001),seq(from=0.015,to=0.1,by=0.002) ) 
  gammaall1<-c(2e-8,1e-8) 
  
  lambdaall<-lambdaall1
  gammaall<-gammaall1
  
  
  k = 5
  set.seed(sample_cv[nruns_i])
  id <- sample(1:k, length(yy[[i]]), replace = TRUE)
  list <- 1:k
  error<-matrix(0,nrow=length(lambdaall1),ncol = length(gammaall1))
  
  for(li in 1:length(lambdaall1)){
    for( gi in 1:length(gammaall1)){
      
      
      for(i_cv in 1:k){
        training_x <- XX[[i]]
        training_x$coefs<-subset(XX[[i]]$coefs , ,id %in% list[-i_cv])
        training_y<-subset(yy[[i]],id %in% list[-i_cv])
        
        testing_x<-XX[[i]] 
        testing_x$coefs<- subset(XX[[i]]$coefs,, id %in% c(i_cv))
        testing_y<-subset(yy[[i]],id %in% list[i_cv])
        
        
        fit <- slos(training_x,training_y,D=NULL,lambda=lambdaall1[li],gamma=gammaall1[gi],intercept=T,beta.basis=beta.basis111,cutoff=1e-5,
                    max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
        
        fitted.values<-predict(fit,testing_x)
        
        error[li,gi]<-sum((fitted.values-testing_y)^2)+error[li,gi]
      }
      
      
    }
  }
  
  loc[[i]]<-which(error==error[which.min(error)],arr.ind=T)
  
  
  now<-slos(XX[[i]],yy[[i]],D=NULL,lambda=lambdaall1[loc[[i]][1,1]],gamma=gammaall1[loc[[i]][1,2]],intercept=T,beta.basis=beta.basis111,cutoff=1e-5,
            max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
  fit_now1[[i]]<-now
}


#  ise and cz fz

beta.dif.original<-rep(0,Mset)

zero.dif.original<-rep(0,Mset)

nozero.dif.original<-rep(0,Mset)

zero.abs.original<-rep(0,Mset)

nozero.abs.original<-rep(0,Mset)

cz.original<-rep(0,Mset)

fz.original<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1:Mset){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  #coe[which(abs(coe)<=sqrt(sum((fit_now1[[i]]$beta[[1]]$coefs)^2))*1e-4)]<-0
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################ ISE0  
  a1<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.original[i]<-a1+a2
  
  ####
  a1<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.abs.original[i]<-a1+a2
  
  
  ############################  ISE
  
  
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  
  ############################  ISE1  
  c<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-c+e
  
  
  
  c<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-c+e
  
  
  ############################  CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=0)/length(t1)
  
  
  
  
  ############################FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=0)/length(t2)
  
  
}


XX<-list()
yy<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}


X<-list()
y<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}




mylambdaall<-c(1,5,10,30,50,100)


fit_before<-list()
 
fit_before[[1]] <- slos(XX[[1]],yy[[1]],D=NULL,lambda=0.07,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[2]] <- slos(XX[[2]],yy[[2]],D=NULL,lambda=0.07,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[3]] <- slos(XX[[3]],yy[[3]],D=NULL,lambda=0.07,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)

error1<-array(0,dim=c(length(lambdaall),length(gammaall),length(mylambdaall)))

for(li in 1:length(lambdaall)){
  for( gi in 1:length(gammaall)){
    for(mi in 1:length(mylambdaall)){
      
      k = 5
      set.seed(sample_cv[nruns_i])
      id <- sample(1:k, length(yy[[i]]), replace = TRUE)
      list <- 1:k
      
      for(i_cv in 1:k){
        training_x <- XX
        training_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          training_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs ,id %in% list[-i_cv])
          training_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[-i_cv])
        }
        testing_x <- XX
        testing_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          testing_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, id %in% list[i_cv])
          testing_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[i_cv])
        }
        
        fit <- int.slos(training_x,training_y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],mylambda=mylambdaall[mi],intercept=T,beta.basis=NULL,cutoff=1e-5,
                        max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis=nbasis)
        
        
        
        error1[li,gi,mi]<-sum((predict(fit[[1]],testing_x[[1]])-testing_y[[1]])^2)
        for(err in 2:Mset){
          error1[li,gi,mi]<-error1[li,gi,mi]+sum((predict(fit[[err]],testing_x[[err]])-testing_y[[err]])^2)
        }
        #####
        
      }
      
      
    }
  }
}


loc1<-which(error1==error1[which.min(error1)],arr.ind=T)
X<-list()
y<-list()
for (ido in 1:Mset) { 
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}

fit.int <- int.slos(X,y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[loc1[1,1]],gamma=gammaall[loc1[1,2]],mylambda=mylambdaall[loc1[1,3]],intercept=T,beta.basis=NULL,cutoff=1e-5,
                    max.iter=1000,tol=1e-3,a=3.7,domain=NULL,tuning=tuning,nbasis = nbasis)


# ise and cz fz
beta.dif.int<-rep(0,Mset)

zero.dif.int<-rep(0,Mset)

nozero.dif.int<-rep(0,Mset)

zero.abs.int<-rep(0,Mset)

nozero.abs.int<-rep(0,Mset)

cz.int<-rep(0,Mset)

fz.int<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1:Mset){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.int[i]<-a1+a2
  
  #####
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.77)$value/0.285
  zero.abs.int[i]<-a1+a2
  
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################ ISE1  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.int[i]<-c+e
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.int[i]<-c+e
  
  
  
  ############################计算零区间上的判断为0的百分比 即CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################计算非零区间上的判断为0的百分比 即FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}




filename=paste(nruns_i,"result_example1.csv",sep="")

write_int<-cbind(cz.int,fz.int,zero.dif.int,nozero.dif.int,zero.abs.int,nozero.abs.int)
write_slos<-cbind(cz.original,fz.original,zero.dif.original,nozero.dif.original,zero.abs.original,nozero.abs.original)
write_result<-cbind(write_int,write_slos)
write_end<-rbind(write_result,apply(write_result,2,mean))


write.csv(write_end,filename)


########################################################################
########################        example 2      #########################
########################################################################



nruns=1000
nSimu=nruns
n=500  ####### Here n was changed !
m=1000
k=1000
N<-n+m+k
intercept=1
rangeval=c(0,1)
Mset<-3
#tuning<- 'CV'

nbasis=50+4-2   #order 是 4   nbreaks 是 50
norder=4
basebeta<-create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
betaxprd<-inprod(basebeta,basebeta)
theta<-inprod(basebeta,basebeta,rng=rangeval)

######################################################## get the beta coef
betacoe<-matrix(0,nrow = nbasis,ncol = Mset)
#get the beta coef

beta.func1 <- function(t){
  
  
  y<-3*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y1<-x
for(i in 1:length(x)){
  y1[i]<-beta.func1(x[i])
}
y1<-pmax(y1,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y1, basisobj)
yfd  <- result$fd
betacoe[,1]<-yfd$coefs
bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ")

###
beta.func2 <- function(t){
  
  
  y<-5*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y2<-x
for(i in 1:length(x)){
  y2[i]<-beta.func2(x[i])
}
y2<-pmax(y2,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y2, basisobj)
yfd  <- result$fd
betacoe[,2]<-yfd$coefs
###

beta.func3 <- function(t){
  
  
  y<-10*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y3<-x
for(i in 1:length(x)){
  y3[i]<-beta.func3(x[i])
}
y3<-pmax(y3,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y3, basisobj)
yfd  <- result$fd
betacoe[,3]<-yfd$coefs


bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

coe<-betacoe[,1]
coe[which(abs(coe)<=sqrt(sum((betacoe[,1])^2))*1e-4)]<-0
betacoe[,1]<-coe

coe<-betacoe[,2]
coe[which(abs(coe)<=sqrt(sum((betacoe[,2])^2))*1e-4)]<-0
betacoe[,2]<-coe

coe<-betacoe[,3]
coe[which(abs(coe)<=sqrt(sum((betacoe[,3])^2))*1e-4)]<-0
betacoe[,3]<-coe


plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ",ylim = c(-3.5,6.5))
lines(fd(betacoe[,2],bspl13),col="red")

lines(fd(betacoe[,3],bspl13),col="blue")

######################################################## error

set.seed(1)
sample1<-sample(1:1e5,nruns,replace = F)

error=list()
for(err_i in 1:nruns){
  set.seed(sample1[err_i])
  error[[err_i]]<-mvrnorm(n=N,mu=rep(0,Mset),Sigma = diag(Mset))  #error[[nruns]][,mset]
}
######################################################## x
set.seed(2)
sample2<-sample(1:1e5,nruns,replace = F)

N <- n + k + m
xmat<-list()
xcoef<-list()
for(m_i in 1:nruns){
  set.seed(sample2[m_i])
  
  xcoef[[m_i]]<-matrix(runif(N*nbasis,min = -5,max = 5),N,nbasis)
  xmat[[m_i]]<-xcoef[[m_i]]%*%betaxprd
}

######################################################## y
dat<-list()
for(mset in 1:Mset){
  train <- list()
  valid <- list()
  test <- list()
  
  for(gen_i in 1:nruns){
    cMat1<-xmat[[gen_i]]
    yTru<-intercept+cMat1%*%betacoe[,mset]
    y <- yTru + error[[gen_i]][,mset]*0.05
    
    train[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][1:n,]),basisobj=basebeta),y=y[1:n],intercept=intercept)
    if(k > 0) valid[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+1):(n+k),]),basisobj=basebeta),
                                     y=y[(n+1):(n+k)],intercept=intercept,yTru=yTru[(n+1):(n+k)])
    if(m > 0) test[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+k+1):N,]),basisobj=basebeta),
                                    y=y[(n+k+1):N],intercept=intercept,yTru=yTru[(n+k+1):N])
  }
  
  dat[[mset]] <- list(train=train,valid=valid,test=test)
  
}


####################################################################
A<-list()

for(iruns in 1:nruns){
  sample<-matrix(0,n,Mset)
  for(imset in 1:Mset){
    sample[,imset]<-dat[[imset]]$train[[iruns]]$y
  }
  
  mycorr <- cor ( sample ) 
  
  
  A[[iruns]]=mycorr
  
}


L<-list()
for(i in 1:nruns){
  DD=matrix(0,Mset,Mset)
  for(DD_i in 1:Mset){
    DD[DD_i,DD_i]<-sum(abs(A[[i]][DD_i,]))
  }
  L[[i]]=DD-A[[i]]
}


####################################################
nruns_i


dat_now<-list()
for(mset in 1:Mset) {
  if (k!=0) {
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=dat[[mset]]$valid[[nruns_i]],test=dat[[mset]]$test[[nruns_i]])
  }
  if(k==0){
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=list(),test=dat[[mset]]$test[[nruns_i]])
    
  }
}
####################

XX<-list()
yy<-list()
for (ido in 1:Mset) {  
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}
fit_now1<-list()

set.seed(1314)
sample_cv<-sample(1:1e5, nruns, replace = FALSE)

for (i in 1:Mset){
  beta.basis111 <- list()
  beta.basis111[[1]] <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
  
  lambdaall=seq(from=0.0005,to=0.001,by=0.00001)
  gammaall<-c(2e-8,1.5e-8,1e-8,9e-9,8e-9,7e-9)
  k = 5
  set.seed(sample_cv[nruns_i])
  id <- sample(1:k, length(yy[[i]]), replace = TRUE)
  list <- 1:k
  error<-matrix(0,nrow=length(lambdaall),ncol = length(gammaall))
  
  for(li in 1:length(lambdaall)){
    for( gi in 1:length(gammaall)){
      
      
      for(i_cv in 1:k){
        training_x <- XX[[i]]
        training_x$coefs<-subset(XX[[i]]$coefs, ,id %in% list[-i_cv])
        training_y<-subset(yy[[i]],id %in% list[-i_cv])
        
        testing_x<-XX[[i]]
        testing_x$coefs<- subset(XX[[i]]$coefs,, id %in% c(i_cv))
        testing_y<-subset(yy[[i]],id %in% list[i_cv])
        
        
        fit <- slos(training_x,training_y,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                    max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
        
        fitted.values<-predict(fit,testing_x)
        
        error[li,gi]<-sum((fitted.values-testing_y)^2)+error[li,gi]
      }
      
      
    }
  }
  
  loc<-which(error==error[which.min(error)],arr.ind=T)
  
  
  now<-slos(XX[[i]],yy[[i]],D=NULL,lambda=lambdaall[loc[1,1]],gamma=gammaall[loc[1,2]],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
            max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
  fit_now1[[i]]<-now
}





#  ise and cz fz

beta.dif.original<-rep(0,Mset)

zero.dif.original<-rep(0,Mset)

nozero.dif.original<-rep(0,Mset)

zero.abs.original<-rep(0,Mset)

nozero.abs.original<-rep(0,Mset)

cz.original<-rep(0,Mset)

fz.original<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1:Mset){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  #coe[which(abs(coe)<=sqrt(sum((fit_now1[[i]]$beta[[1]]$coefs)^2))*1e-4)]<-0
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################ ISE0  
  th_t<-0
  a1<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.original[i]<-a1+a2
  
  ####
  th_t<-0
  a1<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.abs.original[i]<-a1+a2
  
  
  ############################  ISE
  
  
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  
  ############################  ISE1  
  c<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-c+e
  
  
  
  c<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-c+e
  
  
  ############################  CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=th_t)/length(t1)
  
  
  
  
  ############################FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=th_t)/length(t2)
  
  
}




XX<-list()
yy<-list()
for (ido in 1:Mset) { 
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}


X<-list()
y<-list()
for (ido in 1:Mset) {  
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}


lambdaall<-seq(from=0.01,to=0.04,by=0.001)
gammaall<-c(2e-8,1.5e-8,1e-8,9e-9,8.5e-9,8e-9,7.5e-9,7e-9) #6ge
mylambdaall<-c(1,3,5,7,10,30,50)


fit_before<-list()
fit_before[[1]] <- slos(XX[[1]],yy[[1]],D=NULL,lambda=0.005,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[2]] <- slos(XX[[2]],yy[[2]],D=NULL,lambda=0.005,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[3]] <- slos(XX[[3]],yy[[3]],D=NULL,lambda=0.005,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)


error1<-array(0,dim=c(length(lambdaall),length(gammaall),length(mylambdaall)))

for(li in 1:length(lambdaall)){
  for( gi in 1:length(gammaall)){
    for(mi in 1:length(mylambdaall)){
      
      k = 5
      set.seed(sample_cv[nruns_i])
      id <- sample(1:k, length(yy[[i]]), replace = TRUE)
      list <- 1:k
      
      for(i_cv in 1:k){
        training_x <- XX
        training_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          training_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[-i_cv])
          training_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[-i_cv])
        }
        testing_x <- XX
        testing_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          testing_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[i_cv])
          testing_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[i_cv])
        }
        
        fit <- int.slos(training_x,training_y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],mylambda=mylambdaall[mi],intercept=T,beta.basis=NULL,cutoff=1e-5,
                        max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis=nbasis)
        
        
        
        error1[li,gi,mi]<-sum((predict(fit[[1]],testing_x[[1]])-testing_y[[1]])^2)
        for(err in 2:Mset){
          error1[li,gi,mi]<-error1[li,gi,mi]+sum((predict(fit[[err]],testing_x[[err]])-testing_y[[err]])^2)
        }
        #####
        
      }
      
      
    }
  }
}


loc1<-which(error1==error1[which.min(error1)],arr.ind=T)
X<-list()
y<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}

fit.int <- int.slos(X,y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[loc1[1,1]],gamma=gammaall[loc1[1,2]],mylambda=mylambdaall[loc1[1,3]],intercept=T,beta.basis=NULL,cutoff=1e-5,
                    max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis = nbasis)


# ise and cz fz
beta.dif.int<-rep(0,Mset)

zero.dif.int<-rep(0,Mset)

nozero.dif.int<-rep(0,Mset)

zero.abs.int<-rep(0,Mset)

nozero.abs.int<-rep(0,Mset)

cz.int<-rep(0,Mset)

fz.int<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1:Mset){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.int[i]<-a1+a2
  
  #####
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.77)$value/0.285
  zero.abs.int[i]<-a1+a2
  
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################ ISE1  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.int[i]<-c+e
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.int[i]<-c+e
  
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}




filename=paste(nruns_i,"result_example2.csv",sep="")

write_int<-cbind(cz.int,fz.int,zero.dif.int,nozero.dif.int,zero.abs.int,nozero.abs.int)
write_slos<-cbind(cz.original,fz.original,zero.dif.original,nozero.dif.original,zero.abs.original,nozero.abs.original)
write_result<-cbind(write_int,write_slos)
write_end<-rbind(write_result,apply(write_result,2,mean))


write.csv(write_end,filename)


########################################################################
########################        example 3      #########################
########################################################################
nruns=1000
nSimu=nruns
n=500  ####### Here n was changed !
m=1000
k=1000
N<-n+m+k
intercept=1
rangeval=c(0,1)
Mset<-2
#tuning<- 'CV'

nbasis=50+4-2   #order 是 4   nbreaks 是 50
norder=4
basebeta<-create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
betaxprd<-inprod(basebeta,basebeta)  
theta<-inprod(basebeta,basebeta,rng=rangeval)

######################################################## get the beta coef
betacoe<-matrix(0,nrow = nbasis,ncol = Mset)
#get the beta coef

beta.func1 <- function(t){
  
  
  y<-3*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y1<-x
for(i in 1:length(x)){
  y1[i]<-beta.func1(x[i])
}
y1<-pmax(y1,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y1, basisobj)
yfd  <- result$fd
betacoe[,1]<-yfd$coefs
bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ")

###
beta.func2 <- function(t){
  
  
  y<-4*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y2<-x
for(i in 1:length(x)){
  y2[i]<-beta.func2(x[i])
}

y2[1:100]<-pmax(y2[1:100],0)#*c(rep(-1,50),rep(1,51))
y2<-abs(y2)
y2[1:50]<-0

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y2, basisobj)
yfd  <- result$fd
betacoe[,2]<-yfd$coefs
###


bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

coe<-betacoe[,1]
coe[which(abs(coe)<=sqrt(sum((betacoe[,1])^2))*1e-4)]<-0
betacoe[,1]<-coe

coe<-betacoe[,2]
coe[which(abs(coe)<=sqrt(sum((betacoe[,2])^2))*1e-4)]<-0
betacoe[,2]<-coe



plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ",ylim = c(-2,4))
lines(fd(betacoe[,2],bspl13),col="red")


######################################################## error

set.seed(1)
sample1<-sample(1:1e5,nruns,replace = F)

error=list()
for(err_i in 1:nruns){
  set.seed(sample1[err_i])
  error[[err_i]]<-mvrnorm(n=N,mu=rep(0,Mset),Sigma = diag(Mset))  #error[[nruns]][,mset]
}
######################################################## x
set.seed(2)
sample2<-sample(1:1e5,nruns,replace = F)

N <- n + k + m
xmat<-list()
xcoef<-list()
for(m_i in 1:nruns){
  set.seed(sample2[m_i])
  
  #xcoef[[m_i]]<-matrix(rnorm(N*nbasis,mean=10,sd=1),N,nbasis)
  xcoef[[m_i]]<-matrix(runif(N*nbasis,min = -5,max = 5),N,nbasis)
  xmat[[m_i]]<-xcoef[[m_i]]%*%betaxprd
}

######################################################## y
dat<-list()
for(mset in 1:Mset){
  train <- list()
  valid <- list()
  test <- list()
  
  for(gen_i in 1:nruns){
    cMat1<-xmat[[gen_i]]
    yTru<-intercept+cMat1%*%betacoe[,mset]
    y <- yTru + error[[gen_i]][,mset]*0.05
    
    train[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][1:n,]),basisobj=basebeta),y=y[1:n],intercept=intercept)
    if(k > 0) valid[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+1):(n+k),]),basisobj=basebeta),
                                     y=y[(n+1):(n+k)],intercept=intercept,yTru=yTru[(n+1):(n+k)])
    if(m > 0) test[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+k+1):N,]),basisobj=basebeta),
                                    y=y[(n+k+1):N],intercept=intercept,yTru=yTru[(n+k+1):N])
  }
  
  dat[[mset]] <- list(train=train,valid=valid,test=test)
  
}


####################################################################
A<-list()

for(iruns in 1:nruns){
  sample<-matrix(0,n,Mset)
  for(imset in 1:Mset){
    sample[,imset]<-dat[[imset]]$train[[iruns]]$y
  }
  
  mycorr <- cor ( sample ) # 计算所有基因对之间的相关值
  
  
  A[[iruns]]=mycorr
  
}


L<-list()
for(i in 1:nruns){
  DD=matrix(0,Mset,Mset)
  for(DD_i in 1:Mset){
    DD[DD_i,DD_i]<-sum(abs(A[[i]][DD_i,]))
  }
  L[[i]]=DD-A[[i]]
}


####################################################
nruns_i


dat_now<-list()
for(mset in 1:Mset) {
  if (k!=0) {
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=dat[[mset]]$valid[[nruns_i]],test=dat[[mset]]$test[[nruns_i]])
  }
  if(k==0){
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=list(),test=dat[[mset]]$test[[nruns_i]])
    
  }
}
####################

XX<-list()
yy<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}
fit_now1<-list()

set.seed(1314)
sample_cv<-sample(1:1e5, nruns, replace = FALSE)

for (i in 1:Mset){
  beta.basis111 <- list()
  beta.basis111[[1]] <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
  
  lambdaall=c(0.001,0.005,0.008,seq(from=0.01,to=0.04,by=0.001) )
  gammaall<-c(1e-7,1e-8) 
  k = 2
  set.seed(sample_cv[nruns_i])
  id <- sample(1:k, length(yy[[i]]), replace = TRUE)
  list <- 1:k
  error<-matrix(0,nrow=length(lambdaall),ncol = length(gammaall))
  
  for(li in 1:length(lambdaall)){
    for( gi in 1:length(gammaall)){
      
      
      for(i_cv in 1:k){
        training_x <- XX[[i]]
        training_x$coefs<-subset(XX[[i]]$coefs , ,id %in% list[-i_cv])
        training_y<-subset(yy[[i]],id %in% list[-i_cv])
        
        testing_x<-XX[[i]] 
        testing_x$coefs<- subset(XX[[i]]$coefs,, id %in% c(i_cv))
        testing_y<-subset(yy[[i]],id %in% list[i_cv])
        
        
        fit <- slos(training_x,training_y,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                    max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
        
        fitted.values<-predict(fit,testing_x)
        
        error[li,gi]<-sum((fitted.values-testing_y)^2)+error[li,gi]
      }
      
      
    }
  }
  
  loc<-which(error==error[which.min(error)],arr.ind=T)
  
  
  now<-slos(XX[[i]],yy[[i]],D=NULL,lambda=lambdaall[loc[1,1]],gamma=gammaall[loc[1,2]],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
            max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
  fit_now1[[i]]<-now
}





# ise and cz fz


beta.dif.original<-rep(0,Mset)

zero.dif.original<-rep(0,Mset)

nozero.dif.original<-rep(0,Mset)
zero.abs.original<-rep(0,Mset)

nozero.abs.original<-rep(0,Mset)


cz.original<-rep(0,Mset)

fz.original<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################  ISE0  
  a1<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.original[i]<-a1+a2
  
  
  ####
  a1<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.abs.original[i]<-a1+a2
  
  
  
  ############################  ISE
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################  ISE1  
  c<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-c+e
  
  
  c<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-c+e
  
  ############################ CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=0)/length(t1)
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=0)/length(t2)
  
  
  
}

for(i in 2){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################  ISE0  
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.771)$value/0.771
  zero.dif.original[i]<-a2
  
  
  ####
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.771)$value/0.771
  zero.abs.original[i]<-a2
  
  
  
  
  ############################  ISE
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  
  ############################  ISE1  
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-e
  
  
  
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-e
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=0)/length(t1)
  
  ############################ FZ 
  t2<-c(seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=0)/length(t2)
  
  
}


XX<-list()
yy<-list()
for (ido in 1:Mset) { # 
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}


X<-list()
y<-list()
for (ido in 1:Mset) {
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}


lambdaall=c(0.001,0.005,0.008,seq(from=0.01,to=0.04,by=0.001) )
gammaall<-c(1e-7,1e-8) #6ge
mylambdaall<-c(0.1,1,5,10,30,50)

fit_before<-fit_now1
fit_before[[1]] <- slos(XX[[1]],yy[[1]],D=NULL,lambda=0.02,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[2]] <- slos(XX[[2]],yy[[2]],D=NULL,lambda=0.02,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)




error1<-array(0,dim=c(length(lambdaall),length(gammaall),length(mylambdaall)))

for(li in 1:length(lambdaall)){
  for( gi in 1:length(gammaall)){
    for(mi in 1:length(mylambdaall)){
      
      k = 5
      set.seed(sample_cv[nruns_i])
      id <- sample(1:k, length(yy[[i]]), replace = TRUE)
      list <- 1:k
      
      for(i_cv in 1:k){
        training_x <- XX
        training_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          training_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[-i_cv])
          training_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[-i_cv])
        }
        testing_x <- XX
        testing_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          testing_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[i_cv])
          testing_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[i_cv])
        }
        
        fit <- int.slos(training_x,training_y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],mylambda=mylambdaall[mi],intercept=T,beta.basis=NULL,cutoff=1e-5,
                        max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis=nbasis)
        
        
        
        error1[li,gi,mi]<-sum((predict(fit[[1]],testing_x[[1]])-testing_y[[1]])^2)
        for(err in 2:Mset){
          error1[li,gi,mi]<-error1[li,gi,mi]+sum((predict(fit[[err]],testing_x[[err]])-testing_y[[err]])^2)
        }
        #####
        
      }
      
      
    }
  }
}


loc1<-which(error1==error1[which.min(error1)],arr.ind=T)
X<-list()
y<-list()
for (ido in 1:Mset) {  
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}

fit.int <- int.slos(X,y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[loc1[1,1]]*0.01,gamma=gammaall[loc1[1,2]],mylambda=mylambdaall[loc1[1,3]],intercept=T,beta.basis=NULL,cutoff=1e-5,
                    max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis = nbasis)


beta.dif.int<-rep(0,Mset)
zero.dif.int<-rep(0,Mset)
nozero.dif.int<-rep(0,Mset)
zero.abs.int<-rep(0,Mset)
nozero.abs.int<-rep(0,Mset)
cz.int<-rep(0,Mset)
fz.int<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  
  
  
  
  ############################ISE0  
  
  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  zero.dif.int[i]<-a1+a2
  
  #####
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  
  
  zero.abs.int[i]<-a1+a2
  
  ############################  ISE
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################  ISE1  
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.21,0.48)$value/0.27
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.dif.int[i]<-c+e
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.21,0.48)$value/0.27
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.abs.int[i]<-c+e
  
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.49,0.77,by=0.001))
  
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0.21+0.001,0.48-0.001,by=0.001),seq(0.78+0.001,1,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}
for(i in 2){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  
  
  
  
  ############################ ISE0  
  
  
  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.77)$value/0.77
  zero.dif.int[i]<-a2
  
  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0,0.77)$value/0.77
  
  
  zero.abs.int[i]<-a2
  
  ############################  ISE
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################ ISE1  
  
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.dif.int[i]<-e
  
  
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.abs.int[i]<-e
  
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.77,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################fZ 
  ###
  t2<-c(seq(0.78+0.001,1,by=0.001))
  
  
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}


filename=paste(nruns_i,"result_example3.csv",sep="")

write_int<-cbind(cz.int,fz.int,zero.dif.int,nozero.dif.int,zero.abs.int,nozero.abs.int)
write_slos<-cbind(cz.original,fz.original,zero.dif.original,nozero.dif.original,zero.abs.original,nozero.abs.original)
write_result<-cbind(write_int,write_slos)
write_end<-rbind(write_result,apply(write_result,2,mean))


write.csv(write_end,filename)




########################################################################
########################        example 4      #########################
########################################################################
nruns=1000
nSimu=nruns
n=500  ####### Here n was changed !
m=1000
k=1000
N<-n+m+k
intercept=1
rangeval=c(0,1)
Mset<-2
#tuning<- 'CV'

nbasis=50+4-2   #order 是 4   nbreaks 是 50
norder=4
basebeta<-create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
betaxprd<-inprod(basebeta,basebeta)  
theta<-inprod(basebeta,basebeta,rng=rangeval)

######################################################## get the beta coef
betacoe<-matrix(0,nrow = nbasis,ncol = Mset)
#get the beta coef

beta.func1 <- function(t){
  
  
  y<-3*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y1<-x
for(i in 1:length(x)){
  y1[i]<-beta.func1(x[i])
}
y1<-pmax(y1,0)*c(rep(-1,50),rep(1,51))

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y1, basisobj)
yfd  <- result$fd
betacoe[,1]<-yfd$coefs
bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ")

###
beta.func2 <- function(t){
  
  
  y<-4*log(t+1)*sin(3.5*pi*(t-0.2))
  y
}

x <- seq(0,1,0.01)
y2<-x
for(i in 1:length(x)){
  y2[i]<-beta.func2(x[i])
}

y2[50:100]<-pmax(y2[50:100],0)#*c(rep(-1,50),rep(1,51))
y2<-abs(y2)

basisobj <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)
result <- smooth.basis(x, y2, basisobj)
yfd  <- result$fd
betacoe[,2]<-yfd$coefs
###


bspl13 <- create.bspline.basis(rangeval=c(0,1),nbasis=nbasis)

coe<-betacoe[,1]
coe[which(abs(coe)<=sqrt(sum((betacoe[,1])^2))*1e-4)]<-0
betacoe[,1]<-coe

coe<-betacoe[,2]
coe[which(abs(coe)<=sqrt(sum((betacoe[,2])^2))*1e-4)]<-0
betacoe[,2]<-coe



plot(fd(betacoe[,1],bspl13),col="black",xlab=" ",ylab=" ",ylim = c(-2,4))
lines(fd(betacoe[,2],bspl13),col="red")


######################################################## error

set.seed(1)
sample1<-sample(1:1e5,nruns,replace = F)

error=list()
for(err_i in 1:nruns){
  set.seed(sample1[err_i])
  error[[err_i]]<-mvrnorm(n=N,mu=rep(0,Mset),Sigma = diag(Mset))  #error[[nruns]][,mset]
}
######################################################## x
set.seed(2)
sample2<-sample(1:1e5,nruns,replace = F)

N <- n + k + m
xmat<-list()
xcoef<-list()
for(m_i in 1:nruns){
  set.seed(sample2[m_i])
  
  #xcoef[[m_i]]<-matrix(rnorm(N*nbasis,mean=10,sd=1),N,nbasis)
  xcoef[[m_i]]<-matrix(runif(N*nbasis,min = -5,max = 5),N,nbasis)
  xmat[[m_i]]<-xcoef[[m_i]]%*%betaxprd
}

######################################################## y
dat<-list()
for(mset in 1:Mset){
  train <- list()
  valid <- list()
  test <- list()
  
  for(gen_i in 1:nruns){
    cMat1<-xmat[[gen_i]]
    yTru<-intercept+cMat1%*%betacoe[,mset]
    y <- yTru + error[[gen_i]][,mset]*0.1
    
    train[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][1:n,]),basisobj=basebeta),y=y[1:n],intercept=intercept)
    if(k > 0) valid[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+1):(n+k),]),basisobj=basebeta),
                                     y=y[(n+1):(n+k)],intercept=intercept,yTru=yTru[(n+1):(n+k)])
    if(m > 0) test[[gen_i]] <- list(x=fd(coef=t(xcoef[[gen_i]][(n+k+1):N,]),basisobj=basebeta),
                                    y=y[(n+k+1):N],intercept=intercept,yTru=yTru[(n+k+1):N])
  }
  
  dat[[mset]] <- list(train=train,valid=valid,test=test)
  
}


####################################################################
A<-list()

for(iruns in 1:nruns){
  sample<-matrix(0,n,Mset)
  for(imset in 1:Mset){
    sample[,imset]<-dat[[imset]]$train[[iruns]]$y
  }
  
  mycorr <- cor ( sample ) # 计算所有基因对之间的相关值
  
  
  A[[iruns]]=mycorr
  
}


L<-list()
for(i in 1:nruns){
  DD=matrix(0,Mset,Mset)
  for(DD_i in 1:Mset){
    DD[DD_i,DD_i]<-sum(abs(A[[i]][DD_i,]))
  }
  L[[i]]=DD-A[[i]]
}


####################################################
nruns_i


dat_now<-list()
for(mset in 1:Mset) {
  if (k!=0) {
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=dat[[mset]]$valid[[nruns_i]],test=dat[[mset]]$test[[nruns_i]])
  }
  if(k==0){
    dat_now[[mset]]<-list(train=dat[[mset]]$train[[nruns_i]],valid=list(),test=dat[[mset]]$test[[nruns_i]])
    
  }
}
####################

XX<-list()
yy<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}
fit_now1<-list()

set.seed(1314)
sample_cv<-sample(1:1e5, nruns, replace = FALSE)

for (i in 1:Mset){
  beta.basis111 <- list()
  beta.basis111[[1]] <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
  #lambdaall=seq(from=0.0005,to=0.001,by=0.00001) 
  #gammaall<-c(2e-8,1.5e-8,1e-8,9e-9,8e-9,7e-9) 
  
  lambdaall=c(0.001,0.005,0.008,seq(from=0.01,to=0.04,by=0.001) )
  gammaall<-c(1e-7,1e-8) 
  k = 2
  set.seed(sample_cv[nruns_i])
  id <- sample(1:k, length(yy[[i]]), replace = TRUE)
  list <- 1:k
  error<-matrix(0,nrow=length(lambdaall),ncol = length(gammaall))
  
  for(li in 1:length(lambdaall)){
    for( gi in 1:length(gammaall)){
      
      
      for(i_cv in 1:k){
        training_x <- XX[[i]]
        training_x$coefs<-subset(XX[[i]]$coefs , ,id %in% list[-i_cv])
        training_y<-subset(yy[[i]],id %in% list[-i_cv])
        
        testing_x<-XX[[i]] 
        testing_x$coefs<- subset(XX[[i]]$coefs,, id %in% c(i_cv))
        testing_y<-subset(yy[[i]],id %in% list[i_cv])
        
        
        fit <- slos(training_x,training_y,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                    max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
        
        fitted.values<-predict(fit,testing_x)
        
        error[li,gi]<-sum((fitted.values-testing_y)^2)+error[li,gi]
      }
      
      
    }
  }
  
  loc<-which(error==error[which.min(error)],arr.ind=T)
  
  
  now<-slos(XX[[i]],yy[[i]],D=NULL,lambda=lambdaall[loc[1,1]],gamma=gammaall[loc[1,2]],intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
            max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
  fit_now1[[i]]<-now
}




# ise and cz fz

beta.dif.original<-rep(0,Mset)

zero.dif.original<-rep(0,Mset)

nozero.dif.original<-rep(0,Mset)
zero.abs.original<-rep(0,Mset)

nozero.abs.original<-rep(0,Mset)


cz.original<-rep(0,Mset)

fz.original<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################ISE0  
  a1<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.original[i]<-a1+a2
  
  
  
  ####
  a1<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.abs.original[i]<-a1+a2
  
  
  
  
  ############################  ISE
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  
  ############################  ISE1  
  c<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-c+e
  
  
  c<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.2,0.486)$value/0.286
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-c+e
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.486,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=0)/length(t1)
  
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0.2+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=0)/length(t2)
  
  
}

for(i in 2){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit_now1[[i]]$beta[[1]]$coefs
  
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  ############################  ISE0  
  a2<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.dif.original[i]<-a2
  
  
  
  ####
  a2<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.486,0.771)$value/0.285
  zero.abs.original[i]<-a2
  
  
  
  
  ############################  ISE
  beta.dif.original[i]<-integrate(function(t) {(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,1)$value
  
  
  ############################ ISE1  
  c<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.486)$value/0.486
  e<-integrate(function(t) {(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.dif.original[i]<-c+e
  
  
  c<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0,0.486)$value/0.486
  e<-integrate(function(t) {abs(fd.int.bfun(t)-true.bfun(t))},0.771,1)$value/0.229
  nozero.abs.original[i]<-c+e
  
  
  ############################ CZ
  
  t1<-c(seq(0.486,0.771,by=0.001))
  pred <- predict(fd.int.fit,newdata = t1)
  cz.original[i]<-sum(abs(pred)<=0)/length(t1)
  
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0+0.001,0.486-0.001,by=0.001),seq(0.771+0.001,1,by=0.001))
  
  pred <- predict(fd.int.fit,newdata = t2)
  fz.original[i]<-sum(abs(pred)<=0)/length(t2)
  
  
  
}




XX<-list()
yy<-list()
for (ido in 1:Mset) {  
  XX[[ido]]<-dat_now[[ido]]$train$x
  yy[[ido]]<-dat_now[[ido]]$train$y
}


X<-list()
y<-list()
for (ido in 1:Mset) {  
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}


lambdaall=c(0.001,0.005,0.008,seq(from=0.01,to=0.04,by=0.001) )
gammaall<-c(1e-7,1e-8) #6ge
mylambdaall<-c(0.1,1,5,10,30,50)

fit_before<-fit_now1
fit_before[[1]] <- slos(XX[[1]],yy[[1]],D=NULL,lambda=0.02,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)
fit_before[[2]] <- slos(XX[[2]],yy[[2]],D=NULL,lambda=0.02,gamma=1e-8,intercept=T,beta.basis=beta.basis111,cutoff=1e-4,
                        max.iter=1000,tol=1e-3,a=3.7,domain=NULL)




error1<-array(0,dim=c(length(lambdaall),length(gammaall),length(mylambdaall)))

for(li in 1:length(lambdaall)){
  for( gi in 1:length(gammaall)){
    for(mi in 1:length(mylambdaall)){
      
      k = 5
      set.seed(sample_cv[nruns_i])
      id <- sample(1:k, length(yy[[i]]), replace = TRUE)
      list <- 1:k
      
      for(i_cv in 1:k){
        training_x <- XX
        training_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          training_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[-i_cv])
          training_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[-i_cv])
        }
        testing_x <- XX
        testing_y<-yy
        for(lenghtx_i in 1:length(XX)) {
          testing_x[[lenghtx_i]]$coefs<-subset(XX[[lenghtx_i]]$coefs, ,id %in% list[i_cv])
          testing_y[[lenghtx_i]]<-subset(yy[[lenghtx_i]],id %in% list[i_cv])
        }
        
        fit <- int.slos(training_x,training_y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[li],gamma=gammaall[gi],mylambda=mylambdaall[mi],intercept=T,beta.basis=NULL,cutoff=1e-5,
                        max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis=nbasis)
        
        
        
        error1[li,gi,mi]<-sum((predict(fit[[1]],testing_x[[1]])-testing_y[[1]])^2)
        for(err in 2:Mset){
          error1[li,gi,mi]<-error1[li,gi,mi]+sum((predict(fit[[err]],testing_x[[err]])-testing_y[[err]])^2)
        }
        #####
        
      }
      
      
    }
  }
}


loc1<-which(error1==error1[which.min(error1)],arr.ind=T)
X<-list()
y<-list()
for (ido in 1:Mset) { #我们提取出来train的数据放到X和y上面
  X[[ido]]<-dat_now[[ido]]$train$x
  y[[ido]]<-dat_now[[ido]]$train$y
}
#fit_before<-fit_now1
#fit.int <- int.slos(X,y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[min(loc[,1])],gamma=gammaall[max(loc[,2])]*0.1,mylambda=mylambdaall[loc1[1,3]]*1e-7,intercept=T,beta.basis=NULL,cutoff=1e-5,
#                    max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis = nbasis)

fit.int <- int.slos(X,y,fit_before,L=L[[nruns_i]],K=1,theta=theta,D=NULL,lambda=lambdaall[loc1[1,1]]*0.01,gamma=gammaall[loc1[1,2]],mylambda=mylambdaall[loc1[1,3]],intercept=T,beta.basis=NULL,cutoff=1e-5,
                    max.iter=1000,tol=1e-5,a=3.7,domain=NULL,tuning=tuning,nbasis = nbasis)




#  ise and cz fz
beta.dif.int<-rep(0,Mset)
zero.dif.int<-rep(0,Mset)
nozero.dif.int<-rep(0,Mset)
zero.abs.int<-rep(0,Mset)
nozero.abs.int<-rep(0,Mset)
cz.int<-rep(0,Mset)
fz.int<-rep(0,Mset)

bspl13 <- create.bspline.basis(rangeval=rangeval,norder=norder,nbasis=nbasis)
for(i in 1){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  
  
  
  
  ############################ ISE0  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  zero.dif.int[i]<-a1+a2
  
  #####
  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  
  a1<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0,0.2)$value/0.2
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  
  
  zero.abs.int[i]<-a1+a2
  
  ############################ ISE
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################ ISE1  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.21,0.48)$value/0.27
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.dif.int[i]<-c+e
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.21,0.48)$value/0.27
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.abs.int[i]<-c+e
  
  
  
  ############################ CZ
  
  t1<-c(seq(0,0.2,by=0.001),seq(0.49,0.77,by=0.001))
  
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0.21+0.001,0.48-0.001,by=0.001),seq(0.78+0.001,1,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}
for(i in 2){
  
  fd.bspltrue <- fd(betacoe[,i], bspl13)
  true.bfun<-function(t){
    mat <- predict(fd.bspltrue,newdata = c(t))
  }
  
  coe<-fit.int[[i]]$beta[[1]]$coefs
  fd.original<-fd(coe,bspl13)
  fd.original.bfun<-function(t){
    mat<-predict(fd.original,newdata=c(t))
  }
  
  fd.int.fit<- fd(coe, bspl13)
  fd.int.bfun <-function(t){
    mat<-predict(fd.int.fit,newdata=c(t))
  }
  
  
  
  
  
  ############################  ISE0  
  
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  zero.dif.int[i]<-a2
  
  t1<-seq(0,1,by=0.001)
  pred <- predict(fd.int.fit,newdata = t1)
  th_t1<-sqrt(sum((pred)^2))*5e-6
  
  a2<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.int.bfun(t)-true.bfun(t))},0.49,0.77)$value/0.28
  
  
  zero.abs.int[i]<-a2
  
  ############################ ISE
  beta.dif.int[i]<-integrate(function(t) {((fd.int.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.int.bfun(t)-true.bfun(t))*(fd.int.bfun(t)-true.bfun(t))},0,1)$value
  
  ############################ ISE1  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0,0.48)$value/0.48
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*(fd.original.bfun(t)-true.bfun(t))*(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.dif.int[i]<-c+e
  
  
  
  c<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0,0.48)$value/0.48
  e<-integrate(function(t) {((fd.original.bfun(t)-true.bfun(t))>sqrt(th_t1))*abs(fd.original.bfun(t)-true.bfun(t))},0.78,1)$value/0.22
  nozero.abs.int[i]<-c+e
  
  
  
  ############################ CZ
  
  t1<-c(seq(0.49,0.77,by=0.001))
  
  
  pred1 <- predict(fd.original,newdata = t1)
  cz.int[i]<-sum(abs(pred1)<=th_t1)/length(t1)
  
  
  ############################ FZ 
  ###
  t2<-c(seq(0+0.001,0.48-0.001,by=0.001),seq(0.78+0.001,1,by=0.001))
  
  pred1 <- predict(fd.original,newdata = t2)
  fz.int[i]<-sum(abs(pred1)<=th_t1)/length(t2)
  
}




filename=paste(nruns_i,"result_example4.csv",sep="")

write_int<-cbind(cz.int,fz.int,zero.dif.int,nozero.dif.int,zero.abs.int,nozero.abs.int)
write_slos<-cbind(cz.original,fz.original,zero.dif.original,nozero.dif.original,zero.abs.original,nozero.abs.original)
write_result<-cbind(write_int,write_slos)
write_end<-rbind(write_result,apply(write_result,2,mean))


write.csv(write_end,filename)

