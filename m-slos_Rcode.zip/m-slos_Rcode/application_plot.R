########################################################################plot
for(nruns_i in 1:100){
  source("application.R")
}

sumn<-100
mymean<-matrix(0,nrow = sumn,ncol = 8)
for (i in 1:sumn) {
  filename=paste(i,"_application_result.csv",sep="")
  nowresult<-read.csv(filename)
  mymean[i,]<-t(as.matrix(nowresult[,-1]))
}


slos<-mymean[,c(1,2)]
net_slos<-mymean[,c(3,4)]

library(ggplot2)
library(plyr)
library(gridExtra)
ARSE<-c(slos[,1],net_slos[,1])
Model<-c(rep("SLoS",sumn),rep("m-SLoS",sumn))
Model<-as.factor(Model)
fat_mse.data<-data.frame(ARSE,Model)
p1<-ggplot(data=fat_mse.data, aes(x=Model, y=ARSE))+geom_boxplot(aes(fill=Model),notch = T)+ xlab("(a)")+labs(title="Fat")+ 
  theme(plot.title = element_text(hjust = 0.5,lineheight=.8, face="bold")) 

ARSE<-c(slos[,2],net_slos[,2])
Model<-c(rep("SLoS",sumn),rep("m-SLoS",sumn))
Model<-as.factor(Model)
protein.data<-data.frame(ARSE,Model)
p2<-ggplot(data=protein.data, aes(x=Model, y=ARSE))+geom_boxplot(aes(fill=Model),notch = T)+ xlab("(b)")+labs(title="Protein")+ 
  theme(plot.title = element_text(hjust = 0.5,lineheight=.8, face="bold")) 

grid.arrange(p1,p2,ncol=2,nrow=1)

